#!/bin/bash

set -e

printf "🔧 Kompiluję dos.cpp...\n"
g++ -O2 -std=c++17 -o dos dos.cpp
printf "✅ Kompilacja zakończona pomyślnie.\n\n"

GREEN="\033[32m"
RED="\033[31m"
YELLOW="\033[33m"
NC="\033[0m"

for in_file in max/*.in; do
    base_name=$(basename "$in_file" .in)
    out_file="max/${base_name}.out"
    tmp_out="max/${base_name}.out.tmp"

    start_time=$(date +%s%N)
    ./dos < "$in_file" | tr -d '\r' > "$tmp_out"   # ⬅️ usuwa ewentualne CR
    end_time=$(date +%s%N)
    elapsed_ms=$(( (end_time - start_time) / 1000000 ))

    if [ -f "$out_file" ]; then
        # usuń CR też z oczekiwanego pliku
        diff -u -b -B <(tr -d '\r' < "$out_file") "$tmp_out" > /dev/null 2>&1
        if [ $? -eq 0 ]; then
            printf "${GREEN}✅ %s OK${NC} (%d ms)\n" "$base_name" "$elapsed_ms"
        else
            printf "${RED}❌ %s BŁĄD${NC} (%d ms)\n" "$base_name" "$elapsed_ms"
            diff -u -b -B <(tr -d '\r' < "$out_file") "$tmp_out" | head -n 10
            exit 1
        fi
    else
        printf "${YELLOW}⚠️  Brak oczekiwanego pliku wyjścia dla %s${NC}\n" "$base_name"
        exit 1
    fi
done

printf "\n🏁 Testy zakończone.\n"
