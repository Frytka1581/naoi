#!/bin/bash

# --- Ustawienia ---
TEST_DIR="./duze"       # folder z plikami .in i .out
OUT_DIR="./out"         # folder na tymczasowe wyniki programów
PROG1="./han"
PROG2="./mkohan"
COMPILER="g++-14"

# --- Sprawdzenie kompilatora ---
if ! command -v $COMPILER &> /dev/null; then
    echo "❌ Nie znaleziono kompilatora $COMPILER"
    exit 1
fi

# --- Kompilacja programów ---
echo "== Kompilacja =="
$COMPILER -O2 -std=c++17 han.cpp -o han
$COMPILER -O2 -std=c++17 mkohan.cpp -o mkohan
echo

# --- Przygotowanie katalogu wyjściowego ---
mkdir -p "$OUT_DIR"

# --- Liczniki ---
ok_count=0
total=0

# --- Testowanie ---
echo "== Testowanie =="
for input in "$TEST_DIR"/*.in; do
    ((total++))
    testname=$(basename "$input" .in)
    out1="$OUT_DIR/${testname}_han.out"
    out2="$OUT_DIR/${testname}_mkohan.out"
    expected="$TEST_DIR/${testname}.out"

    # Uruchomienie programów i zapis pierwszej linii wyjścia
    head -n 1 <( "$PROG1" < "$input" ) > "$out1"
    head -n 1 <( "$PROG2" < "$input" ) > "$out2"

    # Porównanie wyników obu programów
    # Porównanie wyników obu programów (ignorując spacje)
    if diff -qw "$out1" "$out2" > /dev/null; then
        echo "[$total] ✅ $testname — programy zgodne"
    else
        echo "[$total] ❌ $testname — różne wyniki programów!"
        echo "   → Różnice:"
        diff -w "$out1" "$out2" | sed 's/^/     /'
        exit 1
    fi

    # Porównanie z oczekiwanym wynikiem (ignorując spacje)
    if [[ -f "$expected" ]]; then
        if diff -qw "$out1" <(head -n 1 "$expected") > /dev/null; then
            ((ok_count++))
        else
            echo "[$total] ❌ $testname — wynik niezgodny z oczekiwanym!"
            echo "   → Oczekiwano:"
            head -n 1 "$expected" | sed 's/^/     /'
            echo "   → Otrzymano:"
            cat "$out1" | sed 's/^/     /'
            exit 1
        fi
    else
        ((ok_count++)) # jeśli brak pliku .out, uznajemy zgodność między programami
    fi

done

# --- Podsumowanie ---
echo "== Podsumowanie =="
echo "Poprawnych testów: $ok_count / $total"
